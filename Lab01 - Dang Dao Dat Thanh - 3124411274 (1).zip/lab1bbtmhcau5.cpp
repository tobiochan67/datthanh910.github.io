#include <iostream>
#include <cmath>
using namespace std;

#define MAX 100 // Số lượng phần tử tối đa của dãy

// Nhập mảng số nguyên từ bàn phím
void NhapMang(int **a, int *n) {
    cout << "Mời bạn nhập số lượng phần tử: ";
    cin >> *n;
    while((*n) <= 0 || (*n) > MAX) {
        cout << "Nhập sai! Nhập lại: ";
        cin >> *n;
    }
    *a = new int[*n];
    for(int i = 0; i < *n; i++) {
        cout << "Phần tử " << i << ": ";
        cin >> (*a)[i];
    }
}

// Xuất mảng số nguyên ra màn hình
void XuatMang(int *a, int n) {
    cout << "Dãy số có " << n << " phần tử: ";
    for(int i = 0; i < n; i++) {
        cout << a[i] << " ";
    }
    cout << endl;
}

// Đếm số chẵn trong mảng
int DemChan(int *a, int n) {
    int dem = 0;
    for(int i = 0; i < n; i++) {
        if(a[i] % 2 == 0) dem++;
    }
    return dem;
}

// Tách các số chẵn từ mảng a sang mảng b
void TachChan(int *a, int n, int **b, int *m) {
    *m = DemChan(a, n);
    *b = new int[*m];
    int cs = 0;
    for(int i = 0; i < n; i++) {
        if(a[i] % 2 == 0) {
            (*b)[cs++] = a[i];
        }
    }
}

// Kiểm tra số nguyên tố
bool LaSoNguyenTo(int x) {
    if (x < 2) return false;
    for (int i = 2; i <= sqrt(x); i++) {
        if (x % i == 0) return false;
    }
    return true;
}

// Tạo mảng b chứa số nguyên tố từ mảng a
void TachSoNguyenTo(int *a, int n, int **b, int *m) {
    *m = 0;
    for (int i = 0; i < n; i++) {
        if (LaSoNguyenTo(a[i])) (*m)++;
    }
    *b = new int[*m];
    int cs = 0;
    for (int i = 0; i < n; i++) {
        if (LaSoNguyenTo(a[i])) {
            (*b)[cs++] = a[i];
        }
    }
}

// Kiểm tra dãy có đan dấu không
bool KiemTraDanDau(int *a, int n) {
    for (int i = 1; i < n; i++) {
        if ((a[i] * a[i - 1]) >= 0) return false; // Nếu hai số liền kề cùng dấu
    }
    return true;
}

// Kiểm tra tính đơn điệu của dãy
bool KiemTraDonDieu(int *a, int n) {
    bool tang = true, giam = true;
    for (int i = 1; i < n; i++) {
        if (a[i] > a[i - 1]) giam = false;
        if (a[i] < a[i - 1]) tang = false;
    }
    return tang || giam;
}

// Kiểm tra dãy có đối xứng không
bool KiemTraDoiXung(int *a, int n) {
    for (int i = 0; i < n / 2; i++) {
        if (a[i] != a[n - i - 1]) return false;
    }
    return true;
}

int main() {
    int *b = nullptr, k = 0;
    int *aChan = nullptr, nChan;
    int *aNguyenTo = nullptr, nNguyenTo;
    
    // Nhập dữ liệu
    NhapMang(&b, &k);
    
    // Xử lý tách số chẵn
    TachChan(b, k, &aChan, &nChan);
    
    // Tạo mảng chứa số nguyên tố
    TachSoNguyenTo(b, k, &aNguyenTo, &nNguyenTo);
    
    // Xuất kết quả
    cout << "+ Dãy chứa các số chẵn:\n";
    XuatMang(aChan, nChan);
    
    cout << "+ Dãy chứa các số nguyên tố:\n";
    XuatMang(aNguyenTo, nNguyenTo);
    
    // Kiểm tra các tính chất
    cout << "Dãy có đan dấu không? " << (KiemTraDanDau(b, k) ? "Có" : "Không") << endl;
    cout << "Dãy có đơn điệu không? " << (KiemTraDonDieu(b, k) ? "Có" : "Không") << endl;
    cout << "Dãy có đối xứng không? " << (KiemTraDoiXung(b, k) ? "Có" : "Không") << endl;
    
    // Giải phóng bộ nhớ
    delete[] b;
    delete[] aChan;
    delete[] aNguyenTo;
    
    return 0;
}
