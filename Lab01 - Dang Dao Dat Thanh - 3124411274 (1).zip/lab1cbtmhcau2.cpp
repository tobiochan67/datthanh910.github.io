#include <iostream>
#include <cstring>
using namespace std;

#define MAX 100

// Khai báo cấu trúc Sach
struct Sach {
    char maSach[11];
    char tenSach[21];
    int gia;
};

// Hàm nhập một quyển sách
void Nhap1QuyenSach(Sach &s) {
    cin.ignore();
    cout << "Ma sach: "; cin.getline(s.maSach, 11);
    cout << "Ten sach: "; cin.getline(s.tenSach, 21);
    cout << "Gia: "; cin >> s.gia;
}

// Hàm xuất một quyển sách
void Xuat1QuyenSach(const Sach &s) {
    cout << "Ma sach: " << s.maSach << endl;
    cout << "Ten sach: " << s.tenSach << endl;
    cout << "Gia: " << s.gia << endl;
}

// Hàm nhập danh sách sách
void NhapMangSach(Sach a[], int &n) {
    cout << "Nhap so luong sach: ";
    cin >> n;
    for (int i = 0; i < n; i++) {
        cout << "Nhap quyen sach thu " << i + 1 << ":\n";
        Nhap1QuyenSach(a[i]);
    }
}

// Hàm tìm sách theo mã
bool TimSachTheoMa(Sach a[], int n, const char ma[], Sach &kq) {
    for (int i = 0; i < n; i++) {
        if (strcmp(ma, a[i].maSach) == 0) {
            kq = a[i];
            return true;
        }
    }
    return false;
}

int main() {
    Sach a[MAX];
    int n;
    NhapMangSach(a, n);
    
    cin.ignore();
    char ma[11];
    cout << "Nhap ma sach muon tim: ";
    cin.getline(ma, 11);
    
    Sach kq;
    if (TimSachTheoMa(a, n, ma, kq)) {
        cout << "Quyen sach tim duoc la:\n";
        Xuat1QuyenSach(kq);
    } else {
        cout << "Khong tim thay quyen sach co ma da cho.";
    }
    
    return 0;
}
