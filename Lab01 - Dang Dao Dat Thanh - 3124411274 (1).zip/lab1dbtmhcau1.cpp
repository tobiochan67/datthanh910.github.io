#include <iostream>
#include <string>

using namespace std;

// Hàm kiểm tra chuỗi có chứa ký tự số không
bool CoKyTuSo(const string &s) {
    for (char c : s) {
        if (isdigit(c)) {
            return true;
        }
    }
    return false;
}

int main() {
    string sChuoi;
    
    // Nhập chuỗi
    cout << "Moi ban nhap chuoi: ";
    getline(cin, sChuoi);
    
    // Kiểm tra chuỗi có chứa ký tự số không
    if (CoKyTuSo(sChuoi)) {
        cout << "Chuoi \"" << sChuoi << "\" co chua ky tu so." << endl;
    } else {
        cout << "Chuoi \"" << sChuoi << "\" khong chua ky tu so." << endl;
    }
    
    return 0;
}
