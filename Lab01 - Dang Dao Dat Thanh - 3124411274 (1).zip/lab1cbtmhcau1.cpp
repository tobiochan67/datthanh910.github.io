#include <iostream>
#include <cmath>
using namespace std;

// Khai báo cấu trúc PhanSo
struct PhanSo {
    int tuSo;
    int mauSo;
};

// Hàm nhập phân số
void NhapPhanSo(const string &info, PhanSo &ps) {
    cout << info;
    cin >> ps.tuSo >> ps.mauSo;
    while (ps.mauSo == 0) {
        cout << "Mẫu số không thể bằng 0! Nhập lại: ";
        cin >> ps.mauSo;
    }
}

// Hàm xuất phân số
void XuatPhanSo(const PhanSo &ps) {
    cout << "[" << ps.tuSo << "/" << ps.mauSo << "]";
}

// Hàm rút gọn phân số
void RutGonPhanSo(PhanSo &ps) {
    int a = abs(ps.tuSo), b = abs(ps.mauSo), tmp;
    while (b != 0) {
        tmp = a % b;
        a = b;
        b = tmp;
    }
    ps.tuSo /= a;
    ps.mauSo /= a;
}

// Hàm so sánh hai phân số
int SoSanhPhanSo(PhanSo p1, PhanSo p2) {
    p1.tuSo *= (p1.mauSo < 0) ? -1 : 1;
    p1.mauSo = abs(p1.mauSo);
    p2.tuSo *= (p2.mauSo < 0) ? -1 : 1;
    p2.mauSo = abs(p2.mauSo);
    
    int vp1 = p1.tuSo * p2.mauSo;
    int vp2 = p2.tuSo * p1.mauSo;
    
    if (vp1 > vp2) return 1;
    if (vp1 == vp2) return 0;
    return -1;
}

int main() {
    PhanSo ps1, ps2;
    NhapPhanSo("Nhập phân số thứ nhất: ", ps1);
    NhapPhanSo("Nhập phân số thứ hai: ", ps2);
    
    cout << "Phân số thứ nhất: ";
    XuatPhanSo(ps1);
    cout << "\nPhân số thứ hai: ";
    XuatPhanSo(ps2);
    cout << endl;
    
    RutGonPhanSo(ps1);
    RutGonPhanSo(ps2);
    
    cout << "Phân số thứ nhất sau khi rút gọn: ";
    XuatPhanSo(ps1);
    cout << "\nPhân số thứ hai sau khi rút gọn: ";
    XuatPhanSo(ps2);
    cout << endl;
    
    int ketQua = SoSanhPhanSo(ps1, ps2);
    if (ketQua > 0) {
        cout << "Phân số thứ nhất lớn hơn phân số thứ hai.";
    } else if (ketQua < 0) {
        cout << "Phân số thứ nhất nhỏ hơn phân số thứ hai.";
    } else {
        cout << "Hai phân số bằng nhau.";
    }
    cout << endl;
    
    return 0;
}
