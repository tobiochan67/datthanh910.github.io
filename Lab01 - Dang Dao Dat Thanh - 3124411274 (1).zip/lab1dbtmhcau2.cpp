#include <iostream>
#include <cstring>
using namespace std;

// Hàm kiểm tra chuỗi có đối xứng hay không
bool KiemTraDoiXung(const string &s) {
    int len = s.length();
    for (int i = 0; i < len / 2; i++) {
        if (s[i] != s[len - i - 1]) {
            return false;
        }
    }
    return true;
}

int main() {
    string s;
    cout << "Nhap chuoi: ";
    getline(cin, s);
    
    if (KiemTraDoiXung(s)) {
        cout << "Chuoi doi xung." << endl;
    } else {
        cout << "Chuoi khong doi xung." << endl;
    }
    
    return 0;
}