#include <iostream>
using namespace std;

#define MAX 100 // Số lượng phần tử tối đa của dãy

// Hàm kiểm tra tính chẵn lẻ xen kẽ của mảng
bool KiemTraChanLeXenKe(int *a, int n) {
    for (int i = 1; i < n; i++) {
        if ((a[i] % 2) == (a[i - 1] % 2)) {
            return false;
        }
    }
    return true;
}

// Hàm kiểm tra tính toàn chẵn của mảng
bool KiemTraToanChan(int *a, int n) {
    for (int i = 0; i < n; i++) {
        if (a[i] % 2 != 0) {
            return false;
        }
    }
    return true;
}

// Hàm kiểm tra ký tự nguyên âm
bool LaNguyenAm(char c) {
    c = tolower(c);
    return (c == 'a' || c == 'e' || c == 'i' || c == 'o' || c == 'u');
}

// Hàm tạo mảng b chứa các nguyên âm từ mảng a
void TaoMangNguyenAm(char *a, int n, char *b, int &m) {
    m = 0;
    for (int i = 0; i < n; i++) {
        if (LaNguyenAm(a[i])) {
            b[m++] = a[i];
        }
    }
}

int main() {
    int n;
    int a[MAX];
    
    cout << "Nhập số lượng phần tử của mảng: ";
    cin >> n;
    while (n <= 0 || n > MAX) {
        cout << "Số lượng phần tử không hợp lệ! Nhập lại: ";
        cin >> n;
    }
    
    cout << "Nhập các phần tử của mảng: ";
    for (int i = 0; i < n; i++) {
        cin >> a[i];
    }
    
    if (KiemTraChanLeXenKe(a, n)) {
        cout << "Mảng có tính chẵn lẻ xen kẽ." << endl;
    } else {
        cout << "Mảng không có tính chẵn lẻ xen kẽ." << endl;
    }
    
    if (KiemTraToanChan(a, n)) {
        cout << "Mảng chứa toàn số chẵn." << endl;
    } else {
        cout << "Mảng không chứa toàn số chẵn." << endl;
    }
    
    // Xử lý mảng ký tự
    int m;
    char c[MAX], b[MAX];
    
    cout << "Nhập số lượng ký tự: ";
    cin >> n;
    cout << "Nhập các ký tự: ";
    for (int i = 0; i < n; i++) {
        cin >> c[i];
    }
    
    TaoMangNguyenAm(c, n, b, m);
    
    cout << "Mảng chứa các nguyên âm: ";
    for (int i = 0; i < m; i++) {
        cout << b[i] << " ";
    }
    cout << endl;
    
    return 0;
}
