#include<iostream>
#include<cmath>
#include<iomanip>
using namespace std;
int main()
{
    float a,b,c;
    float t1,t2,t;
	cin>>a;
	cin>>b;
	cin>>c;
	float x1,x2,x3,x4,x5,x6;
	float d=(b*b)-(4*a*c);
	if (d>0)	
	{
		cout<<"pt co 4 nghiem"<<endl;
		t1=(-b+sqrt(d))/2*a;
		t2=(-b-sqrt(d))/2*a;
		x1=sqrt(t1);
		x2=-sqrt(t1);
		x3=sqrt(t2);
		x4=-sqrt(t2);
		cout<<fixed<<x1<<" "<<x2<<" "<<x3<<" "<<x4;
	}
	
    if ((a!=0||b!=0||c!=0)&&(d==0))
    {
	   cout<<"pt co 2 nghiem"<<endl;
	   t=-b/2*a;
	   x5=sqrt(t);
	   x6=-sqrt(t);
	   cout<<fixed<<x5<<" "<<x6;
    }
    if (a==0&&b==0&&c==0&&d==0)
    {
        cout<<"pt vo so nghiem";
    }
	if (d<0)
    {
       cout<<"pt vo nghiem";
    }
	return 0;
}