#include<iostream>
#include<cmath>
#include<iomanip>
using namespace std;
int main()
{
    float a,b,c;
    float x1,x2,x;
	cin>>a;
	cin>>b;
	cin>>c;
	float d=(b*b)-(4*a*c);
	if (d>0)	
	{
		cout<<"pt co 2 nghiem"<<endl;
		x1=(-b+sqrt(d))/2*a;
		x2=(-b-sqrt(d))/2*a;
		cout<<setprecision(2)<<x1<<" "<<x2;
	}
	
    if ((a!=0||b!=0||c!=0)&&(d==0))
    {
	   cout<<"pt co 1 nghiem"<<endl;
	   x=-b/2*a;
	   cout<<setprecision(2)<<x;
    }
    if (a==0&&b==0&&c==0&&d==0)
    {
        cout<<"pt vo so nghiem";
    }
	if (d<0)
    {
       cout<<"pt vo nghiem";
    }
	return 0;
}