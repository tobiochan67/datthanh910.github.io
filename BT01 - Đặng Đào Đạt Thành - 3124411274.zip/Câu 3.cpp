#include <iostream>
using namespace std;
void nhap (int a[],int &na)
{
    cin>>na;
    for (int i=0;i<na;i++)
    {
        cin>>a[i];
    }
}
void xuat(int a[],int na)
{   
    cout<<endl<<na<<"\n";
    for(int i=0;i<na;i++)
    {
        cout<<a[i]<<" ";
    }
}
void ptchung(int a[],int &na,int b[],int &nb,int c[],int &nc,int d[],int &nd)
{
    nhap (a,na);
    nhap (b,nb);
    nhap (c,nc);
    nd=0;int flag=0;
    for (int i=0;i<na;i++)
    {   
        if(i>0)
        {   
            flag=0;
            for(int y=i-1;y>=0;y--)
            {
                if(a[i]==a[y])
                {
                    flag=1;       //kt pt trung nhau 
                    break;
                }
            }
        }
        if(flag==0)
        {
            for (int j=0;j<nb;j++)
            {
                if(a[i]==b[j])
                {
                    for (int f=0;f<nc;f++)
                    {
                        if(b[j]==c[f])
                        {
                            d[nd]=a[i];
                            nd++;
                            break;
                        }
                    }
                    break;
                }
            }
        }
    }
}
void sxt(int a[],int na)
{
    for (int i=0;i<na-1;i++)
    {
        for (int j=i+1;j<na;j++)
        {
            if(a[i]>a[j])swap(a[i],a[j]);
        }
    }
}

int main ()
{
    int a[1001],na,b[1001],nb,c[1001],nc,d[1001],nd;
    ptchung(a,na,b,nb,c,nc,d,nd);
    sxt(d,nd);
    xuat(d,nd);
    return 0;
}
