#include <stdio.h>

typedef struct node {
    int info;
    struct node* next;
} Node;

void Init(Node*& pHead) {
    pHead = NULL;
}

bool IsEmpty(Node* pHead) {
    return (pHead == NULL);
}

Node* CreateNode(int X) {
    Node* p = new Node;
    if (!p) return NULL; // Kiểm tra cấp phát bộ nhớ
    p->info = X;
    p->next = NULL;
    return p;
}

void ShowList(Node* pHead) {
    Node* p = pHead;
    if (p == NULL)
        printf("Danh sach rong");
    else {
        while (p != NULL) {
            printf("%d \t", p->info);
            p = p->next;
        }
        printf(" ");
    }
}

Node* Find(Node* pHead, int x) {
    Node* p = pHead;
    while (p != NULL) {
        if (p->info == x)
            return p;
        p = p->next;
    }
    return NULL;
}

void InsertFirst(Node*& pHead, int x) {
    Node* p = CreateNode(x);
    if (!p) return; // Kiểm tra cấp phát bộ nhớ
    p->next = pHead;
    pHead = p;
}

void InsertAfter(Node* p, int x) {
    if (p != NULL) {
        Node* q = CreateNode(x);
        if (!q) return; // Kiểm tra cấp phát bộ nhớ
        q->next = p->next;
        p->next = q;
    }
}

void InsertOrder(Node*& pHead, int x) {
    if (pHead == NULL || pHead->info >= x) {
        InsertFirst(pHead, x);
        return;
    }

    Node* p = pHead;
    while (p->next != NULL && p->next->info < x) {
        p = p->next;
    }
    InsertAfter(p, x);
}

void DeleteFirst(Node*& pHead) {
    if (IsEmpty(pHead)) {
        printf("List is empty!");
        return;
    }
    Node* p = pHead;
    pHead = pHead->next;
    delete p;
}

void DeleteAfter(Node* p) {
    if (p == NULL || p->next == NULL) {
        printf("Khong the xoa nut nay!");
        return;
    }
    Node* q = p->next;
    p->next = q->next;
    delete q;
}

void Remove(Node*& pHead, int x) {
    if (pHead == NULL) return;

    Node* p = pHead, * tp = NULL;
    while (p != NULL && p->info != x) {
        tp = p;
        p = p->next;
    }

    if (p == NULL) return; // Không tìm thấy

    if (p == pHead) // Nếu là phần tử đầu
        pHead = p->next;
    else
        tp->next = p->next;

    delete p;
}

void ClearList(Node*& pHead) {
    Node* p;
    while (pHead != NULL) {
        p = pHead;
        pHead = pHead->next;
        delete p;
    }
}
void SelectionSort(Node*& pHead) {
    if (pHead == NULL) return; // Kiểm tra danh sách rỗng

    Node* p, * q, * pmin;
    int vmin;
    for (p = pHead; p->next != NULL; p = p->next) {
        pmin = p;
        for (q = p->next; q != NULL; q = q->next) {
            if (q->info < pmin->info) {
                pmin = q;
            }
        }
        if (pmin != p) { // Hoán đổi giá trị
            vmin = p->info;
            p->info = pmin->info;
            pmin->info = vmin;
        }
    }
}
int main() {
    Node* pHead = NULL;
    Init(pHead);

    InsertFirst(pHead, 10);
    InsertFirst(pHead, 20);
    InsertFirst(pHead, 30);

    ShowList(pHead); // Kết quả mong đợi: 30  20  10

    Node* foundNode = Find(pHead, 20);
    if (foundNode != NULL)
        printf("Tim thay phan tu: %d", foundNode->info);
    else
        printf("Khong tim thay phan tu!");

    DeleteFirst(pHead);
    ShowList(pHead); // Kết quả mong đợi: 20  10

    InsertOrder(pHead, 15);
    ShowList(pHead); // Kết quả mong đợi: 10  15  20

    Remove(pHead, 15);
    ShowList(pHead); // Kết quả mong đợi: 10  20

    InsertFirst(pHead, 5);
    InsertFirst(pHead, 25);
    SelectionSort(pHead);
    ShowList(pHead); // Kết quả mong đợi: 5  10  20  25

    ClearList(pHead);
    ShowList(pHead); // Kết quả mong đợi: Danh sach rong

    return 0;
}