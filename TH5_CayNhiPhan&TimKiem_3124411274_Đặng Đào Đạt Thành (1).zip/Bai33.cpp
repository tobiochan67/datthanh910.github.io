#include <iostream>
#include <cstdio> 
using namespace std;
struct node {
    float info;
    struct node *pLeft, *pRight;
};
typedef struct node NODE;
typedef NODE *TREE;
void Init(TREE &t) {
    t = NULL;
}
void InsertNode(TREE &t, float x) {
    TREE newNode = new NODE;
    newNode->info = x;
    newNode->pLeft = newNode->pRight = NULL;
    if (t == NULL) {
        t = newNode;
        return;
    }
    TREE cur = t, parent = NULL;
    while (cur) {
        parent = cur;
        if (x < cur->info)
            cur = cur->pLeft;
        else if (x > cur->info)
            cur = cur->pRight;
        else
            return; // Không chèn giá trị trùng
    }
    if (x < parent->info)
        parent->pLeft = newNode;
    else
        parent->pRight = newNode;
}

// NLR không đệ quy (Dùng mảng thay Stack)
void NLR(TREE t, FILE *fp) {
    if (!t) return;
    TREE stack[100]; // Dùng mảng thay vì stack STL
    int top = -1;    
    stack[++top] = t; // Đẩy gốc vào stack
    while (top >= 0) { 
        TREE cur = stack[top--]; // Lấy phần tử trên cùng
        fwrite(&cur->info, sizeof(float), 1, fp); // Ghi vào file
        if (cur->pRight) stack[++top] = cur->pRight; // Đẩy con phải trước
        if (cur->pLeft) stack[++top] = cur->pLeft;   // Đẩy con trái sau
    }
}
//Duyệt theo mức không đệ quy (Dùng mảng thay Queue)
void LevelOrder(TREE t, FILE *fp) {
    if (!t) return;
    TREE queue[100]; // Dùng mảng thay vì queue STL
    int front = 0, rear = 0;
    queue[rear++] = t; // Đẩy gốc vào hàng đợi
    while (front < rear) { 
        TREE cur = queue[front++]; // Lấy phần tử đầu tiên
        fwrite(&cur->info, sizeof(float), 1, fp); // Ghi vào file
        if (cur->pLeft) queue[rear++] = cur->pLeft;   // Đẩy con trái vào hàng đợi
        if (cur->pRight) queue[rear++] = cur->pRight; // Đẩy con phải vào hàng đợi
    }
}
int Xuat(const char *filename, TREE t, void (*traverse)(TREE, FILE *)) {
    FILE *fp = fopen(filename, "wb");
    if (fp == NULL)
        return 0;
    traverse(t, fp);
    fclose(fp);
    return 1;
}
int main() {
    TREE t;
    Init(t);  
    int n;
    float x;
    cout << "Nhap so luong phan tu: ";
    cin >> n;
    cout << "Nhap cac gia tri: ";
    for (int i = 0; i < n; i++) {
        cin >> x;
        InsertNode(t, x);
    }
    // Xuất theo NLR (Stack)
    if (Xuat("nlr_output.bin", t, NLR))
        cout << "Ghi file NLR thanh cong: nlr_output.bin\n";
    else
        cout << "Ghi file NLR that bai!\n";
    // Xuất theo Level Order (Queue)
    if (Xuat("level_output.bin", t, LevelOrder))
        cout << "Ghi file theo muc thanh cong: level_output.bin\n";
    else
        cout << "Ghi file theo muc that bai!\n";
    return 0;
}
