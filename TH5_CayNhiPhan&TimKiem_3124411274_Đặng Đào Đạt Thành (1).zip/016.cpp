#include <iostream>
using namespace std;
struct BST_NODE {
    int Key;      
    int So_lan;   
    BST_NODE *Left, *Right;
};
struct BST_TREE {
    BST_NODE *pRoot;
};
void Init(BST_TREE &t) {
    t.pRoot = NULL;
}
BST_NODE *CreateNode(int x) {
    BST_NODE *p = new BST_NODE;
    if (p == NULL)
        return NULL;
    p->Key = x;
    p->So_lan = 1;
    p->Left = p->Right = NULL;
    return p;
}
void InsertNode(BST_TREE &t, int x) {
    BST_NODE *p = t.pRoot, *prev = NULL;

    while (p != NULL) {
        prev = p;
        if (x == p->Key) {
            p->So_lan++;
            return;
        }
        if (x < p->Key)
            p = p->Left;
        else
            p = p->Right;
    }

    BST_NODE *newNode = CreateNode(x);
    if (prev == NULL) {
        t.pRoot = newNode;
    } else if (x < prev->Key) {
        prev->Left = newNode;
    } else {
        prev->Right = newNode;
    }
}
int DeleteNode(BST_NODE *Root, int x) {
    if (Root == NULL)
        return 0;
    if (Root->Key == x) {
        if (Root->So_lan > 0) {
            Root->So_lan--;
            return 1;
        }
        return 0;
    }
    if (x < Root->Key)
        return DeleteNode(Root->Left, x);
    return DeleteNode(Root->Right, x);
}
void XoaGiaTri(BST_TREE &t, int x) {
    int kq = DeleteNode(t.pRoot, x);
    if (kq == 0)
        cout << "Khong ton tai " << x << endl;
    else
        cout << "Xoa thanh cong " << x << endl;
}
void NLR(BST_NODE *Root) {
    if (Root == NULL)
        return;
    if (Root->So_lan > 0)
        cout << Root->Key << " ";
    NLR(Root->Left);
    NLR(Root->Right);
}
void LietKe(BST_TREE &t) {
    NLR(t.pRoot);
    cout << endl;
}
int main() {
    BST_TREE t;
    Init(t);
    int n, x;
    cout << "Nhap so luong phan tu: ";
    cin >> n;
    cout << "Nhap cac gia tri: ";
    for (int i = 0; i < n; i++) {
        cin >> x;
        InsertNode(t, x);
    }
    cout << "Cay sau khi nhap (NLR): ";
    LietKe(t);
    cout << "Nhap gia tri can xoa: ";
    cin >> x;
    XoaGiaTri(t, x);
    cout << "Cay sau khi xoa (NLR): ";
    LietKe(t);
    return 0;
}
