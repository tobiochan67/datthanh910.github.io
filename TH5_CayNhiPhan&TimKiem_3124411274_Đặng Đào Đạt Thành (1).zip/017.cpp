#include <iostream>
using namespace std;
struct node {
    float info;
    struct node* pLeft;
    struct node* pRight;
};
typedef struct node NODE;
typedef NODE* TREE;
void Init(TREE &t) {
    t = NULL;
}
NODE* CreateNode(float x) {
    NODE* p = new NODE;
    if (p == NULL) return NULL;
    p->info = x;
    p->pLeft = p->pRight = NULL;
    return p;
}
void InsertNode(TREE &t, float x) {
    if (t == NULL) {
        t = CreateNode(x);
    } else if (x < t->info) {
        InsertNode(t->pLeft, x);
    } else if (x > t->info) {
        InsertNode(t->pRight, x);
    }
}
void SearchStandFor(TREE &p, TREE &q) {
    if (q->pLeft != NULL) {
        SearchStandFor(p, q->pLeft);
    } else {
        p->info = q->info;
        TREE temp = q;
        q = q->pRight;
        delete temp;
    }
}
void DeleteNode(TREE &t, float x) {
    if (t == NULL) return;

    if (x < t->info) {
        DeleteNode(t->pLeft, x);
    } else if (x > t->info) {
        DeleteNode(t->pRight, x);
    } else {
        TREE p = t;
        if (t->pLeft == NULL) {
            t = t->pRight;
        } else if (t->pRight == NULL) {
            t = t->pLeft;
        } else {
            SearchStandFor(p, t->pRight);
        }
        delete p;
    }
}
void NLR(TREE t) {
    if (t == NULL) return;
    cout << t->info << " ";
    NLR(t->pLeft);
    NLR(t->pRight);
}
int main() {
    TREE t;
    Init(t);
    int n;
    float x;
    cin >> n;
    for (int i = 0; i < n; i++) {
        cin >> x;
        InsertNode(t, x);
    }
    NLR(t);
    cout << endl;
    cin >> x;
    DeleteNode(t, x);
    NLR(t);
    cout << endl;
    return 0;
}
