#include <iostream>
using namespace std;
struct node {
    int info;
    struct node* pLeft;
    struct node* pRight;
};
typedef struct node NODE;
typedef NODE* TREE;
void Init(TREE &t) {
    t = NULL;
}
NODE* GetNode(int x) {
    NODE* p = new NODE;
    if (p == NULL) return NULL;
    p->info = x;
    p->pLeft = p->pRight = NULL;
    return p;
}
int InsertNode(TREE &t, int x) {
    if (t) {
        if (t->info == x) return 0; // Tránh trùng lặp
        if (t->info < x)
            return InsertNode(t->pRight, x);
        return InsertNode(t->pLeft, x);
    }
    t = GetNode(x);
    if (t == NULL) return -1; // Lỗi cấp phát
    return 1;
}
int TaoCay(TREE &t, int a[], int n) {
    Init(t);
    for (int i = 0; i < n; i++) {
        if (InsertNode(t, a[i]) == -1) return 0;
    }
    return 1;
}
void LNR(TREE t, int a[], int &n) {
    if (t == NULL) return;
    LNR(t->pLeft, a, n);
    a[n] = t->info;
    n++;
    LNR(t->pRight, a, n);
}
int main() {
    TREE t;
    int n;
    cout << "Nhap so luong phan tu: ";
    cin >> n;
    int *a = new int[n];
    cout << "Nhap cac gia tri: ";
    for (int i = 0; i < n; i++) {
        cin >> a[i];
    }
    if (TaoCay(t, a, n)) {
        n = 0;
        LNR(t, a, n);
        cout << "Cac phan tu theo thu tu LNR: ";
        for (int i = 0; i < n; i++) {
            cout << a[i] << " ";
        }
        cout << endl;
    } else {
        cout << "Loi khi tao cay." << endl;
    }
    delete[] a;
    return 0;
}
