#include <iostream>
using namespace std;
struct nodetree {
    int info;
    struct nodetree *pLeft, *pRight;
};
typedef struct nodetree NODETREE;
typedef NODETREE *TREE;
struct nodelist {
    int info;
    struct nodelist *pNext;
};
typedef struct nodelist NODELIST;
struct list {
    NODELIST *pHead;
    NODELIST *pTail;
};
typedef struct list LIST;
void Init(LIST &l) {
    l.pHead = l.pTail = NULL;
}
NODELIST *GetNode(int x) {
    NODELIST *p = new NODELIST;
    if (p == NULL)
        return NULL;
    p->info = x;
    p->pNext = NULL;
    return p;
}
void AddTail(LIST &l, NODELIST *p) {
    if (l.pHead == NULL)
        l.pHead = l.pTail = p;
    else {
        l.pTail->pNext = p;
        l.pTail = p;
    }
}
void InsertNode(TREE &t, int x) {
    if (t == NULL) {
        t = new NODETREE;
        t->info = x;
        t->pLeft = t->pRight = NULL;
    } else if (x < t->info) {
        InsertNode(t->pLeft, x);
    } else if (x > t->info) {
        InsertNode(t->pRight, x);
    }
}
void RNL(TREE Root, LIST &l) {
    if (Root == NULL)
        return;
    RNL(Root->pRight, l);
    NODELIST *p = GetNode(Root->info);
    if (p != NULL)
        AddTail(l, p);
    RNL(Root->pLeft, l);
}
void BuildList(TREE Root, LIST &l) {
    Init(l);
    RNL(Root, l);
}
void PrintList(LIST l) {
    NODELIST *p = l.pHead;
    while (p != NULL) {
        cout << p->info << " ";
        p = p->pNext;
    }
    cout << endl;
}
int main() {
    TREE t = NULL;
    LIST l;  
    int n, x;
    cout << "Nhap so luong phan tu: ";
    cin >> n;
    cout << "Nhap cac gia tri: ";
    for (int i = 0; i < n; i++) {
        cin >> x;
        InsertNode(t, x);
    }
    BuildList(t, l);
    cout << "Danh sach lien ket (RNL): ";
    PrintList(l);
    return 0;
}
