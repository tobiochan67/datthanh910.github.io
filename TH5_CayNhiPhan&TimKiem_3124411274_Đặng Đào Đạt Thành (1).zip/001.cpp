#include<iostream>
using namespace std;
struct node
{
 int info;
 struct node*pLeft;
 struct node*pRight;
};
typedef struct node NODE;
typedef NODE*TREE;

int DemNode(TREE Root)
{
if(Root==NULL)
return 0;
int a=DemNode(Root->pLeft);
int b=DemNode(Root->pRight);
return (a+b+1);
}
int TongNode(TREE Root)
{
if(Root==NULL)
return 0;
int a=TongNode(Root->pLeft);
int b=TongNode(Root->pRight);
return (a+b+Root->info);
}
float TrungBinhCong(TREE Root)
{
int s = TongNode(Root);
int dem = DemNode(Root);
if(dem==0)
return 0;
return (float)s/dem;
}
int DemDuong(TREE Root)
{
 if(Root==NULL)
 return 0;
 int a=DemDuong(Root->pLeft);
 int b=DemDuong(Root->pRight);
 if(Root->info>0)
 return (a+b+1);
 return (a+b);
}
int TongDuong(TREE Root)
{
 if(Root==NULL)
 return 0;
 int a=TongDuong(Root->pLeft);
 int b=TongDuong(Root->pRight);
 if(Root->info>0)
 return (a+b+Root->info);
 return (a+b);
}
float TrungBinhDuong(TREE Root)
{
 int s = TongDuong(Root);
 int dem=DemDuong(Root);
 if(dem==0)
 return 0;
 return (float)s/dem;
}
int DemAm(TREE Root)
{
 if(Root==NULL)
 return 0;
 int a=DemAm(Root->pLeft);
 int b=DemAm(Root->pRight);
 if(Root->info<0)
 return (a+b+1);
 return (a+b);
}
int TongAm(TREE Root)
{
 if(Root==NULL)
 return 0;
 int a=TongAm(Root->pLeft);
 int b=TongAm(Root->pRight);
 if(Root->info<0)
 return (a+b+Root->info);
 return (a+b);
}
float TrungBinhCongAm(TREE Root)
{
 int s = TongAm(Root);
 int dem = DemAm(Root);
 if(dem==0)
 return 0;
 return (float)s/dem;
}
float TinhTySo(TREE Root)
{
 int a = TongDuong(Root);
 int b = TongAm(Root);
 if(b==0)
 return 0;
 return (float)a/b;
}

NODE* CreateNode(int x) {
    NODE* p = new NODE;
    if (p == NULL)
        return NULL;
    p->info = x;
    p->pLeft = p->pRight = NULL;
    return p;
}


void InsertNode(TREE &Root, int x) {
    if (Root == NULL) {
        Root = CreateNode(x);
    } else {
        if (x < Root->info)
            InsertNode(Root->pLeft, x);
        else if (x > Root->info)
            InsertNode(Root->pRight, x);
    }
}
int main() {
    TREE Root = NULL;
    InsertNode(Root, 10);
    InsertNode(Root, -5);
    InsertNode(Root, 20);
    InsertNode(Root, 15);
    InsertNode(Root, -10);
    InsertNode(Root, 25);
    InsertNode(Root, 5);
    cout << "Tong cac node: " << TongNode(Root) << endl;
    cout << "So luong node: " << DemNode(Root) << endl;
    cout << "Trung binh cong: " << TrungBinhCong(Root) << endl;
    cout << "Tong cac node duong: " << TongDuong(Root) << endl;
    cout << "Trung binh cong so duong: " << TrungBinhDuong(Root) << endl;
    cout << "Tong cac node am: " << TongAm(Root) << endl;
    cout << "Trung binh cong so am: " << TrungBinhCongAm(Root) << endl;
    cout << "Ty so TongDuong/TongAm: " << TinhTySo(Root) << endl;
    return 0;
}
