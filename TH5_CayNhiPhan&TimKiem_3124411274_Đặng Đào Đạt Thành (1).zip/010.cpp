#include <iostream>
#include <cstdio> 
using namespace std;
struct node {
    float info;
    struct node *pLeft, *pRight;
};
typedef struct node NODE;
typedef NODE *TREE;
void Init(TREE &t) {
    t = NULL;
}
void InsertNode(TREE &t, float x) {
    if (t == NULL) {
        t = new NODE;
        t->info = x;
        t->pLeft = t->pRight = NULL;
    } else if (x < t->info) {
        InsertNode(t->pLeft, x);
    } else if (x > t->info) {
        InsertNode(t->pRight, x);
    }
}
void LRN(TREE t, FILE *fp) {
    if (t == NULL)
        return;
    LRN(t->pLeft, fp);
    LRN(t->pRight, fp);
    fwrite(&t->info, sizeof(float), 1, fp);
}
int Xuat(const char *filename, TREE t) {
    FILE *fp = fopen(filename, "wb");
    if (fp == NULL)
        return 0;
    LRN(t, fp);
    fclose(fp);
    return 1;
}
int main() {
    TREE t;
    Init(t);  
    int n;
    float x;
    cout << "Nhap so luong phan tu: ";
    cin >> n;
    cout << "Nhap cac gia tri: ";
    for (int i = 0; i < n; i++) {
        cin >> x;
        InsertNode(t, x);
    }
    const char *filename = "output.bin";
    if (Xuat(filename, t))
        cout << "Ghi file thanh cong: " << filename << endl;
    else
        cout << "Ghi file that bai!" << endl;
    return 0;
}
