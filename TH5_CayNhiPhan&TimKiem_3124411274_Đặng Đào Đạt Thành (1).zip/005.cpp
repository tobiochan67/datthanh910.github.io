#include <iostream>
using namespace std;
struct node {
    int info;
    struct node *pLeft, *pRight;
};
typedef struct node NODE;
typedef NODE *TREE;
void Init(TREE &t) {
    t = NULL;
}
void InsertNode(TREE &t, int x) {
    if (t == NULL) {
        t = new NODE;
        t->info = x;
        t->pLeft = t->pRight = NULL;
    } else if (x < t->info) {
        InsertNode(t->pLeft, x);
    } else if (x > t->info) {
        InsertNode(t->pRight, x);
    }
}
int DemMotCon(TREE t) {
    if (t == NULL)
        return 0;
    if ((t->pLeft && !t->pRight) || (!t->pLeft && t->pRight))
        return 1 + DemMotCon(t->pLeft) + DemMotCon(t->pRight);
    return DemMotCon(t->pLeft) + DemMotCon(t->pRight);
}
int main() {
    TREE t;
    Init(t);
    int n, x;
    cout << "Nhap so luong phan tu: ";
    cin >> n;
    cout << "Nhap cac gia tri: ";
    for (int i = 0; i < n; i++) {
        cin >> x;
        InsertNode(t, x);
    }
    int soNutMotCon = DemMotCon(t);
    cout << "So nut co dung mot con: " << soNutMotCon << endl;
    return 0;
}
