#include <iostream>
#include <cmath> // Dùng abs()
using namespace std;
struct node {
    int info;
    struct node* pLeft;
    struct node* pRight;
};
typedef struct node NODE;
typedef NODE* TREE;
void Init(TREE &t) {
    t = NULL;
}
NODE* GetNode(int x) {
    NODE* p = new NODE;
    if (p == NULL) return NULL;
    p->info = x;
    p->pLeft = p->pRight = NULL;
    return p;
}
int InsertNode(TREE &t, int x) {
    if (t) {
        if (t->info == x) return 0; // Tránh trùng lặp
        if (t->info < x)
            return InsertNode(t->pRight, x);
        return InsertNode(t->pLeft, x);
    }
    t = GetNode(x);
    if (t == NULL) return -1; // Lỗi cấp phát
    return 1;
}
NODE* LonNhat(TREE t) {
    if (t == NULL) return NULL;
    NODE* lc = t;
    NODE* a = LonNhat(t->pLeft);
    if (a && a->info > lc->info) lc = a;
    NODE* b = LonNhat(t->pRight);
    if (b && b->info > lc->info) lc = b;
    return lc;
}
NODE* NhoNhat(TREE t) {
    if (t == NULL) return NULL;
    NODE* lc = t;
    NODE* a = NhoNhat(t->pLeft);
    if (a && a->info < lc->info) lc = a;
    NODE* b = NhoNhat(t->pRight);
    if (b && b->info < lc->info) lc = b;
    return lc;
}
int ChieuCao(TREE t) {
    if (t == NULL) return 0;
    int a = ChieuCao(t->pLeft);
    int b = ChieuCao(t->pRight);
    return max(a, b) + 1;
}
int ktCanBang(TREE Root) {
    if (Root == NULL) return 1;
    if (ktCanBang(Root->pLeft) == 0) return 0;
    if (ktCanBang(Root->pRight) == 0) return 0;
    NODE* a = LonNhat(Root->pLeft);
    if (a && a->info > Root->info) return 0;
    a = NhoNhat(Root->pRight);
    if (a && a->info < Root->info) return 0;
    int x = ChieuCao(Root->pLeft);
    int y = ChieuCao(Root->pRight);
    if (abs(x - y) > 1) return 0;
    return 1;
}
void LNR(TREE t) {
    if (t == NULL) return;
    LNR(t->pLeft);
    cout << t->info << " ";
    LNR(t->pRight);
}
int main() {
    TREE t;
    Init(t);
    int n;
    cout << "Nhap so luong phan tu: ";
    cin >> n;
    int x;
    cout << "Nhap cac gia tri: ";
    for (int i = 0; i < n; i++) {
        cin >> x;
        InsertNode(t, x);
    }
    cout << "Cay theo thu tu LNR: ";
    LNR(t);
    cout << endl;
    if (ktCanBang(t))
        cout << "Cay can bang." << endl;
    else
        cout << "Cay khong can bang." << endl;
    NODE* maxNode = LonNhat(t);
    NODE* minNode = NhoNhat(t);
    if (maxNode) cout << "Gia tri lon nhat: " << maxNode->info << endl;
    if (minNode) cout << "Gia tri nho nhat: " << minNode->info << endl;
    return 0;
}
