#include <iostream>
using namespace std;
struct node {
    int info;
    struct node* pLeft;
    struct node* pRight;
};
typedef struct node NODE;
typedef NODE* TREE;
void Init(TREE &t) {
    t = NULL;
}
NODE* GetNode(int x) {
    NODE* p = new NODE;
    if (p == NULL) return NULL;
    p->info = x;
    p->pLeft = p->pRight = NULL;
    return p;
}
int InsertNode(TREE &t, int x) {
    if (t) {
        if (t->info == x) return 0; // Tránh trùng lặp
        if (t->info < x)
            return InsertNode(t->pRight, x);
        return InsertNode(t->pLeft, x);
    }
    t = GetNode(x);
    if (t == NULL) return -1; // Lỗi cấp phát
    return 1;
}
void LNR(TREE t) {
    if (t == NULL) return;
    LNR(t->pLeft);
    cout << t->info << " ";
    LNR(t->pRight);
}
void RemoveAll(TREE &t) {
    if (t == NULL) return;
    RemoveAll(t->pLeft);
    RemoveAll(t->pRight);
    delete t;
    t = NULL;
}
int main() {
    TREE t;
    Init(t);
    int n;
    cout << "Nhap so luong phan tu: ";
    cin >> n;
    int x;
    cout << "Nhap cac gia tri: ";
    for (int i = 0; i < n; i++) {
        cin >> x;
        InsertNode(t, x);
    }
    cout << "Cay theo thu tu LNR: ";
    LNR(t);
    cout << endl;
    RemoveAll(t);
    if (t == NULL)
        cout << "Cay da duoc xoa hoan toan." << endl;
    else
        cout << "Xoa cay khong thanh cong." << endl;
    return 0;
}
