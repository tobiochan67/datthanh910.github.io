#include <iostream>
using namespace std;

struct node {
    int info;
    struct node *pLeft, *pRight;
};
typedef struct node NODE;
typedef NODE *TREE;
void Init(TREE &t) {
    t = NULL;
}
void InsertNode(TREE &t, int x) {
    if (t == NULL) {
        t = new NODE;
        t->info = x;
        t->pLeft = t->pRight = NULL;
    } else if (x < t->info) {
        InsertNode(t->pLeft, x);
    } else if (x > t->info) {
        InsertNode(t->pRight, x);
    }
}
NODE* NhoNhat(TREE Root) {
    if (Root == NULL)
        return NULL;
    NODE *lc = Root;
    while (lc->pLeft)
        lc = lc->pLeft;
    return lc;
}
NODE* LonNhat(TREE Root) {
    if (Root == NULL)
        return NULL;
    NODE *lc = Root;
    while (lc->pRight)
        lc = lc->pRight;
    return lc;
}
int main() {
    TREE t;
    Init(t);
    int n, x;
    cout << "Nhap so luong phan tu: ";
    cin >> n;
    cout << "Nhap cac gia tri: ";
    for (int i = 0; i < n; i++) {
        cin >> x;
        InsertNode(t, x);
    }
    NODE *minNode = NhoNhat(t);
    NODE *maxNode = LonNhat(t);
    if (minNode)
        cout << "Phan tu nho nhat: " << minNode->info << endl;
    if (maxNode)
        cout << "Phan tu lon nhat: " << maxNode->info << endl;
    return 0;
}
