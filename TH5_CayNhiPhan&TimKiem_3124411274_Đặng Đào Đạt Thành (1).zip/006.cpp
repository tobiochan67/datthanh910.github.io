#include <iostream>
using namespace std;
struct node {
    int info;
    struct node *pLeft, *pRight;
};
typedef struct node NODE;
typedef NODE *TREE;
void Init(TREE &t) {
    t = NULL;
}
void InsertNode(TREE &t, int x) {
    if (t == NULL) {
        t = new NODE;
        t->info = x;
        t->pLeft = t->pRight = NULL;
    } else if (x < t->info) {
        InsertNode(t->pLeft, x);
    } else if (x > t->info) {
        InsertNode(t->pRight, x);
    }
}
int DemNode(TREE t) {
    if (t == NULL)
        return 0;
    int a = DemNode(t->pLeft);
    int b = DemNode(t->pRight);
    return (a + b + 1);
}
int TongNode(TREE t) {
    if (t == NULL)
        return 0;
    int a = TongNode(t->pLeft);
    int b = TongNode(t->pRight);
    return (a + b + t->info);
}
int main() {
    TREE t;
    Init(t);
    int n, x;
    cout << "Nhap so luong phan tu: ";
    cin >> n;
    cout << "Nhap cac gia tri: ";
    for (int i = 0; i < n; i++) {
        cin >> x;
        InsertNode(t, x);
    }
    int soLuongNode = DemNode(t);
    int tongGiaTri = TongNode(t);
    cout << "So luong nut trong cay: " << soLuongNode << endl;
    cout << "Tong gia tri cac nut: " << tongGiaTri << endl;
    return 0;
}
